import { AuthService } from 'src/app/core/auth.service';
import { Component, OnInit } from '@angular/core';
import { BreakPoint } from '@angular/flex-layout';
import { BreakpointObserver, Breakpoints, BreakpointState } from '@angular/cdk/layout';
import {Observable } from 'rxjs';


@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.css']
})
export class SidenavComponent implements OnInit {
  collapsedHeight: string= '50px';
  expandedHeight: string= '50px';

  isHandset: Observable<BreakpointState> = this.breakpointObserver.observe(Breakpoints.Handset);

  constructor(private breakpointObserver: BreakpointObserver,private _authService: AuthService) { }

  ngOnInit() {
  }
  logout() {
     this._authService.signOut();
  }
}
