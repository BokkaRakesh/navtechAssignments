import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AngularFireModule } from '@angular/fire';
import { AngularFirestoreModule } from '@angular/fire/firestore';
import { AngularFireStorageModule, StorageBucket } from '@angular/fire/storage';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustomMaterialModule } from './shared/custom-material/custom-material.module';
import { environment } from 'src/environments/environment';
import { SidenavComponent } from './sidenav/sidenav.component';

import { DatePipe } from '@angular/common';
import { AgmCoreModule } from '@agm/core';

import { OrdersModule } from './modules/orders/orders.module';
import { AngularFireAuthModule } from '@angular/fire/auth';

@NgModule({
  declarations: [
    AppComponent,
    SidenavComponent,

  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AngularFireModule.initializeApp(environment.firebase),
    AngularFirestoreModule,
    AngularFireAuthModule,
    AngularFireStorageModule,
    AppRoutingModule,
    CustomMaterialModule,


    OrdersModule
  ],
  providers: [DatePipe  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
