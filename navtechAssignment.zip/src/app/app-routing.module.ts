import { DashboardComponent } from './dashboard/pages/dashboard/dashboard.component';
import {
  NgModule
} from '@angular/core';
import {
  Routes,
  RouterModule
} from '@angular/router';
import {
  AuthGuard
} from './core/auth.guard';
import { NoAuthGuard } from './core/no-auth.guard';
import { SidenavComponent } from './sidenav/sidenav.component';

const routes: Routes = [{
  path: '',
  redirectTo: 'dashboard',
  pathMatch: 'full'
},  {
  path: 'login',
  loadChildren: './login/login.module#LoginModule',
  canActivate: [NoAuthGuard]
},{
  path: 'dashboard',
  component: SidenavComponent,
  loadChildren: './dashboard/dashboard.module#DashboardModule',
  canActivate: [AuthGuard]
},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
