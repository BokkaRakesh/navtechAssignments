import { CustomMaterialModule } from 'src/app/shared/custom-material/custom-material.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LoginRoutingModule } from './login-routing.module';
import { LoginComponent } from './pages/login/login.component';
import { ForgotPasswordComponent } from './pages/forgot-password/forgot-password.component';
import { MatButtonModule, MatInputModule, MatIconModule, MatCheckboxModule } from '@angular/material';

@NgModule({
  declarations: [LoginComponent, ForgotPasswordComponent],
  imports: [CommonModule, LoginRoutingModule, CustomMaterialModule]
})
export class LoginModule {}
