
import { AuthService } from 'src/app/core/auth.service';
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';

import { Login } from './login.model';
import { ToastService } from 'src/app/core/service/toast/toast.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  /* --------------------------------- Fields --------------------------------- */
  loginForm: FormGroup;

  /* ------------------------------- Constructor ------------------------------ */

  // constructor(private _fb: FormBuilder, private _auth: AuthService) {}
  constructor(
    private readonly _fb: FormBuilder,
    private readonly _authService: AuthService,
    private readonly _toastService: ToastService
  ) {}

  /* --------------------------- Life Cycle Methods --------------------------- */

  ngOnInit(): void {
    this.loginForm = this._fb.group({
      email: [null, [Validators.required, Validators.email]],
      password: [null, Validators.required]
    });
  }

  /* --------------------------------- Getters -------------------------------- */

  get email(): AbstractControl {
    return this.loginForm.get('email');
  }
  get password(): AbstractControl {
    return this.loginForm.get('password');
  }

  /* ----------------------------- Custom Methods ----------------------------- */
  async login(): Promise<void> {
    const login = this.loginForm.value as Login;

    console.log(login);
    try {
      return this._authService.emailLogin(login.email, login.password);
    } catch (error) {
      console.log(error);
      this._toastService.openSnackBar(`Invalid Login Credentials`);

      return;
    }
  }
}
