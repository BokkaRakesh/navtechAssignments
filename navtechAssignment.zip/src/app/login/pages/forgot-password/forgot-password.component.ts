import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import { AuthService } from 'src/app/core/auth.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  /* --------------------------------- Fields --------------------------------- */
  forgotPasswordForm: FormGroup;

  /* ------------------------------- Constructor ------------------------------ */

  constructor(private readonly _fb: FormBuilder, private readonly _authService: AuthService) {}

  /* --------------------------- Life Cycle Methods --------------------------- */

  ngOnInit(): void {
    this.forgotPasswordForm = this._fb.group({
      email: [undefined, [Validators.required, Validators.email]]
    });
  }

  /* --------------------------------- Getters -------------------------------- */
  get email(): AbstractControl {
    return this.forgotPasswordForm.get('email');
  }

  /* ----------------------------- Custom Methods ----------------------------- */

  async resetPassword(): Promise<void> {
    const forgotPasswordFormData = this.forgotPasswordForm.value;
    console.log(forgotPasswordFormData.email);
    try {
      return this._authService.resetPassword(forgotPasswordFormData.email);
    } catch (error) {
      return;
    }
  }
}
