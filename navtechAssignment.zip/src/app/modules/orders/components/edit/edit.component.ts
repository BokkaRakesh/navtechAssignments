import { OrderService } from '../../services/order.service';
import { Order } from '../../models/order.model';
import {
  ElementRef,
  ViewChild,
  Component,
  OnInit,
  Inject
} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators
} from '@angular/forms';
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  /* --------------------------------- Fields --------------------------------- */
  orderForm: FormGroup;
  newOrder: Order;
  uploadPercent: number;
  downloadURL: string;
  public latitude: number;
  public longitude: number;
  public searchControl: FormControl;
  public zoom: number;

  @ViewChild('search')
  public searchElementRef: ElementRef;

  /* ------------------------------- Contructor ------------------------------- */
  constructor(
    private _fb: FormBuilder,
    public _dialogref: MatDialogRef<EditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: Order,
    private _orderService: OrderService,
  ) {}

  /* ----------------------------- Life Cycle Hook ---------------------------- */
  ngOnInit() {
    this.orderForm = this._fb.group({
       id: [null],
  orderNumber: [null,  Validators.required],
  orderDueDate: [null,  Validators.required],
  buyerName: [null,  Validators.required],
  address : [null,  Validators.required],
  mobile: [null,  Validators.required],
  total: [null,  Validators.required],
    });
     this._orderService
    .getOrderById(this.data.id)
    .subscribe(order => {
      console.log(order);
      this.orderForm.setValue(order);
    });
  }

  /* ---------------------------- Custom Functions ---------------------------- */

  onNoClick(): void {
    this._dialogref.close();
    this.orderForm.reset();
  }
  async updateFunction(): Promise<void> {
    if (this.orderForm.valid) {
      this.newOrder = {
        id: this.id.value,
        orderNumber: this.orderNumber.value,
        orderDueDate: this.orderDueDate.value,
        buyerName: this.buyerName.value,
        mobile: this.mobile.value,
        address: this.address.value,
        total: this.total.value
      };
      const orderSuccess = await this._orderService.updateOrder(this.newOrder);
      if (orderSuccess) {
        this.orderForm.reset();
        this._dialogref.close(true);
      }
      return;
    }
  }

  closeDialog() {
    this.orderForm.reset();
    this._dialogref.close(true);
  }



  /* --------------------------------- Getters -------------------------------- */
  get id() {
    return this.orderForm.get('id');
  }
  get orderNumber() {
    return this.orderForm.get('orderNumber');
  }
  get orderDueDate() {
    return this.orderForm.get('orderDueDate');
  }
  get buyerName() {
    return this.orderForm.get('buyerName');
  }
  get total() {
    return this.orderForm.get('total');
  }
  get address() {
    return this.orderForm.get('address');
  }
  get mobile() {
    return this.orderForm.get('mobile');
  }
}
