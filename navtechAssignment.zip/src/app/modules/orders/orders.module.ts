import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OrdersRoutingModule } from './orders-routing.module';
import { ListComponent } from './pages/list/list.component';
import { AddComponent } from './components/add/add.component';
import { EditComponent } from './components/edit/edit.component';
import { CustomMaterialModule } from 'src/app/shared/custom-material/custom-material.module';

@NgModule({
  declarations: [ListComponent, AddComponent, EditComponent],
  imports: [
    CommonModule,
    OrdersRoutingModule,
    CustomMaterialModule
  ],
  entryComponents: [
    AddComponent,
    EditComponent
  ]
})
export class OrdersModule { }
