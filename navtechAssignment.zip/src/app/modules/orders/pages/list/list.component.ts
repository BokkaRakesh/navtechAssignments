import { Component, OnInit, ViewChild} from '@angular/core';
import { AddComponent } from '../../components/add/add.component';
import { MatTableDataSource, MatDialog, MatSort, MatPaginator } from '@angular/material';
import { Order } from '../../models/order.model';
import { OrderService } from '../../services/order.service';
import { Subscription } from 'rxjs';
import { EditComponent } from '../../components/edit/edit.component';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  displayedColumns: string[] = ['srNo', 'orderNumber', 'orderDueDate', 'buyerName', 'address', 'mobile', 'total', 'manage'];
  dataSource: MatTableDataSource<Order>;
  pageLength: number;
  subscription: Subscription;

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator : MatPaginator;

/* ------------------------------- Constructor ------------------------------- */

  constructor(private _orderservice: OrderService, public _dialog: MatDialog) {

  }

/* ---------------------------- Life Cycle Hooks ---------------------------- */

  ngOnInit() {
    this.subscription = this._orderservice.getOrder().subscribe(data => {
      this.dataSource = new MatTableDataSource<Order>(data);
      this.pageLength = data.length;
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
    });
  }
  onDestroy(){
    this.subscription.unsubscribe();
  }

/* ------------------------------ Custom Functions ------------------------------ */

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  openDialog(): void {
    const dialogRef = this._dialog.open(AddComponent, {
      width: '500px',
      data: {name:'I am Rakesh'}
    });

    dialogRef.afterClosed().subscribe(result => {
        console.log(result);
    });
  }
  async deleteOrder(id): Promise<void>{
    const deleteSuccess = await this._orderservice.deleteOrder(id);
    if(deleteSuccess){
      return;
    }
  }
  editDialog(id): void{
    const dialogRef = this._dialog.open(EditComponent, {
      width: '500px',
      data: {id}
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
    });
  }

}
