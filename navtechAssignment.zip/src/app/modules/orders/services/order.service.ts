import  { ToastService } from "src/app/core/service/toast/toast.service";
import { AngularFirestore } from '@angular/fire/firestore';
import { Injectable } from '@angular/core';
import { Order } from '../models/order.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private _afs: AngularFirestore, private _toast: ToastService) { }
  /*-------------------------- Add Order -------------------------*/
  async addOrder(order: Order): Promise < boolean > {
      try {
          console.log(`add Order : ${order}`);
          order.id = this._afs.createId();
          await this._afs.doc(`orders/${order.id}`).set(order);
          this._toast.openSnackBar(`Order added successfully`);
          return true;
      } catch (error) {

          this._toast.openSnackBar(`unable to add Order`);
          return false;
      }
  }

  /*--------------------------- Update Order ---------------------------*/

  async updateOrder(order: Order): Promise < boolean > {
      try {
          console.log(`update Order :  ${order}`);
          await this._afs.doc(`orders/${order.id}`).set(order);
          this._toast.openSnackBar(`Order updated`);
          return true;
      } catch (error) {

          this._toast.openSnackBar(`unable to update Order`);
          return false;
      }
  }

  /*--------------------------------- delete Order ---------------------------------*/

  async deleteOrder(id): Promise < boolean > {
      console.log(`Order delete called `);

      try {
          await this._afs.doc(`orders/${id}`).delete();
          this._toast.openSnackBar(`deleted Order successfully`);
          return;
      } catch (error) {

          this._toast.openSnackBar(`deleting Order failed`);
          return;
      }
  }

  /*----------------------- get all Order ----------------------*/
  getOrder(): Observable <Order[]> {
      console.log(`get all Order details`);
      return this._afs
          .collection<Order>(`orders`)
          .valueChanges();
  }

  /*----------------------------- Get Order by id -----------------------------*/
  getOrderById(id): Observable <Order> {
      return this._afs
          .doc<Order>(`orders/${id}`)
          .valueChanges()
  }
}
