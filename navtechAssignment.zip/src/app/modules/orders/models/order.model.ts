export interface Order{
  id: string;
  orderNumber: string;
  orderDueDate: string;
  buyerName: string;
  address : string;
  mobile: string;
  total: string;
}
