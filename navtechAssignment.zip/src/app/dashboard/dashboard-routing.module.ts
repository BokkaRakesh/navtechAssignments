import {
  NgModule
} from '@angular/core';
import {
  Routes,
  RouterModule
} from '@angular/router';
import {
  AuthGuard
} from '../core/auth.guard';
import { NoAuthGuard } from '../core/no-auth.guard';

const routes: Routes = [{
  path: '',
  redirectTo: 'orders',
  pathMatch: 'full'
},
{
path: 'orders',
loadChildren: '../modules/orders/orders.module#OrdersModule'
},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule {}
