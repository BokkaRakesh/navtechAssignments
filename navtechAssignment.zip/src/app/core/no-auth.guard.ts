import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';
import { SecuredLsService } from './secured-ls.service';

@Injectable({
  providedIn: 'root'
})
export class NoAuthGuard implements CanActivate {
  constructor(
    private readonly router: Router,
    private readonly _sls: SecuredLsService,
    private readonly _authService: AuthService
  ) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean | UrlTree {

    const user = this._sls.get('user');

    if (user) {
      console.log('already logged in');
      return this.router.parseUrl('/dashboard');
    } else {
      return true;
    }
  }
}
