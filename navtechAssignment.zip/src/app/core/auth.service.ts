import { SecuredLsService } from './secured-ls.service';

import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import { Router } from '@angular/router';
import { auth, User } from 'firebase/app';
import { ToastService } from './service/toast/toast.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  /* --------------------------------- Fields --------------------------------- */

  user: User;


  /* ------------------------------- Constructor ------------------------------ */

  constructor(
    private readonly _afAuth: AngularFireAuth,
    private readonly _router: Router,
    private readonly _sls: SecuredLsService,
    private readonly _toastService: ToastService
  ) {
    /* ----------------------------- Custom Methods ----------------------------- */

    // we subscribe to the authentication state; if the user is logged in,
    // we add the user's data to the browser's local storage; otherwise we store a undefined user

    this._afAuth.authState.subscribe(user => {
      if (user) {
        this.user = user;
        this._sls.set('user', this.user);
      }
    });
  }

  // Login Status
  isLoggedIn(): boolean {
    return this.user ? true : false;
  }

  // Logs user in if existing
  async emailLogin(email: string, password: string): Promise<void> {
    try {
      await this._afAuth.auth.signInWithEmailAndPassword(email, password);
      this._toastService.openSnackBar('Admin Logged In Successfully');
      this._router.navigate(['/dashboard']);
      return;
    } catch (error) {
      console.log(`Admin Login error: ${error}`);
      this._toastService.openSnackBar('Admin Logging Failed');
      return;
    }
  }

  // Resets current user password if exists
  async resetPassword(email: string): Promise<void> {
    const fbAuth = auth();
    try {
      await fbAuth.sendPasswordResetEmail(email);
      this._toastService.openSnackBar('Password Reset Link Sent - Check your email');
      this._router.navigate(['/login']);
      return;
    } catch (error) {
      console.log(`Reset Password: ${error}`);
      this._toastService.openSnackBar('Please enter correct email');

      return;
    }
  }

  // Signs User Out
  async signOut(): Promise<void> {
    try {
      await this._afAuth.auth.signOut();
      this._toastService.openSnackBar('Admin Logout out ...');
      this._sls.removeKeys('user');
      this._router.navigate(['/login']);
      return;
    } catch (error) {
      console.log(`Logout error: ${error}`);
      this._toastService.openSnackBar('Unable to Logout');

      return;
    }
  }
}
