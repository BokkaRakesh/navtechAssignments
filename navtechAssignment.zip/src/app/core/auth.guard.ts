
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { SecuredLsService } from './secured-ls.service';
import { ToastService } from './service/toast/toast.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(
    private readonly router: Router,
    private readonly _sls: SecuredLsService,
    private readonly _ts: ToastService
  ) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean | UrlTree {

    const user = this._sls.get('user');
    if (user) {
      console.log('Valid Login');
      return true;
    } else {
      console.log('Invalid Login login');
      return this.router.parseUrl('/login');
    }
  }
}
