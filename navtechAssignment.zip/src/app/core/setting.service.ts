import { Injectable } from '@angular/core';


export interface LoggingSetting {
  loggingEnabled: boolean;
}

export interface Branch {
  activeBranchId: string;
  activeBranchName: string;
}

@Injectable({
  providedIn: 'root'
})
export class SettingService {

  constructor() {

  }
}
