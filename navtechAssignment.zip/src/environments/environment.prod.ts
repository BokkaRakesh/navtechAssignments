export const environment = {
  production: false,
  firebase : {
    apiKey: "AIzaSyA-DY5bIKYZvO_zPzRm4wCb0ZhwzaP0kho",
    authDomain: "navtech-a542f.firebaseapp.com",
    databaseURL: "https://navtech-a542f.firebaseio.com",
    projectId: "navtech-a542f",
    storageBucket: "navtech-a542f.appspot.com",
    messagingSenderId: "836215519489",
    appId: "1:836215519489:web:7b031938edd53b51"
  },
  lsKey: 'tZJaq72y3buBxQAPTPv4'
};
