// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebase : {
    apiKey: "AIzaSyA-DY5bIKYZvO_zPzRm4wCb0ZhwzaP0kho",
    authDomain: "navtech-a542f.firebaseapp.com",
    databaseURL: "https://navtech-a542f.firebaseio.com",
    projectId: "navtech-a542f",
    storageBucket: "navtech-a542f.appspot.com",
    messagingSenderId: "836215519489",
    appId: "1:836215519489:web:7b031938edd53b51"
  },
  lsKey: 'tZJaq72y3buBxQAPTPv4'
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
